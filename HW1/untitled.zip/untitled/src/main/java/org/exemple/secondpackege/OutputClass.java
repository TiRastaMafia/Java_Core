package org.exemple.secondpackege;
/* 
@autor Stanchu Vladislav
*/

public class OutputClass {
    public static void result(String name){
        System.out.printf("Hello, %s", name);

    }
}
